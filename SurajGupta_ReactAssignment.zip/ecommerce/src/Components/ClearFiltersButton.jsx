


import React from "react";

function ClearFiltersButton({ onClick }) {
  return <button onClick={onClick} style={{ padding: "10px 20px", margin: 10, background: "#007bff", color: "white", border: "none", cursor: "pointer" }}>Clear Filters</button>;
}

export default ClearFiltersButton;
