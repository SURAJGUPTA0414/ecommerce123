
import React from "react";

function SearchBar({ value, onSearchChange }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <input type="text" value={value} onChange={(e) => onSearchChange(e.target.value)}
        placeholder="Search products..." style={{ padding: 10, border: "1px solid #ddd", borderRadius: 5, width: "100%" }} />
    </div>
  );
}

export default SearchBar;
