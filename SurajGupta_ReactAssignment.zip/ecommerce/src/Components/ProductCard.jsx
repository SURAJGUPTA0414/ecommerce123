

import React from "react";
import styled from "styled-components";

const Card = styled.div`
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
  width: 220px;
  text-align: center;
`;

const Image = styled.img`
  width: 150px;
  height: 150px;
`;

const Button = styled.button`
  background-color: orange;
  color: white;
  border: none;
  padding: 10px;
  margin: 5px;
  cursor: pointer;
  width: 100px;
`;

function ProductCard({ product }) {
  return (
    <Card>
      <Image src={product.image} alt={product.title} />
      <h3>{product.title}</h3>
      <p>⭐ {product.rating.rate} ({product.rating.count})</p>
      <p>${product.price}</p>
      <Button>Buy Now</Button>
      <Button>Add to Cart</Button>
    </Card>
  );
}

export default ProductCard;
