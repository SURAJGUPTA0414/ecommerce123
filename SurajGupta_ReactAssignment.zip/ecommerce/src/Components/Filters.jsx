
import React from "react";

const priceRanges = [{ label: "$0 - $100", min: 0, max: 100 }, { label: "$100 - $200", min: 100, max: 200 }];
const categories = ["electronics", "jewelery", "men's clothing", "women's clothing"];

function Filters({ filters, onCategoryChange, onPriceChange, onRatingChange }) {
  return (
    <div>
      <h4>Categories</h4>
      {categories.map((cat) => (
        <label key={cat}>
          <input type="checkbox" checked={filters.category.includes(cat)}
            onChange={(e) => onCategoryChange(e.target.checked ? [...filters.category, cat] : filters.category.filter((c) => c !== cat))} />
          {cat}
        </label>
      ))}
      <h4>Price</h4>
      {priceRanges.map(({ label, min, max }) => (
        <label key={label}>
          <input type="radio" name="price" checked={filters.minPrice === min && filters.maxPrice === max}
            onChange={() => onPriceChange({ min, max })} /> {label}
        </label>
      ))}
      <h4>Rating</h4>
      {[1, 2, 3, 4, 5].map((star) => (
        <label key={star}>
          <input type="radio" name="rating" checked={filters.rating === star}
            onChange={() => onRatingChange(star)} /> {"★".repeat(star)}
        </label>
      ))}
    </div>
  );
}

export default Filters;
