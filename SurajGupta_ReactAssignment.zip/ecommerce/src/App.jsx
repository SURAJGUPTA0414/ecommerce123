
import React, { useState, useEffect } from "react";
import axios from "axios";
import ProductList from "./Components/ProductList";
import Filters from "./Components/Filters";
import SearchBar from "./Components/SearchBar";
import ClearFiltersButton from "./Components/ClearFiltersButton";

function App() {
  const [products, setProducts] = useState([]);
  const [filters, setFilters] = useState({
    category: [],
    minPrice: "",
    maxPrice: "",
    rating: 0,
    searchQuery: "",
  });

  useEffect(() => {
    axios.get("https://fakestoreapi.com/products")
      .then((res) => setProducts(res.data))
      .catch((err) => console.error("Error fetching products:", err));
  }, []);

  const updateFilters = (type, value) => setFilters((prev) => ({ ...prev, [type]: value }));
  const clearFilters = () => setFilters({ category: [], minPrice: "", maxPrice: "", rating: 0, searchQuery: "" });

  const filteredProducts = products.filter((p) => 
    (!filters.searchQuery || p.title.toLowerCase().includes(filters.searchQuery.toLowerCase())) &&
    (!filters.category.length || filters.category.includes(p.category)) &&
    (!filters.minPrice || p.price >= filters.minPrice) &&
    (!filters.maxPrice || p.price <= filters.maxPrice) &&
    (!filters.rating || p.rating.rate >= filters.rating)
  );

  return (
    <div style={{ padding: 20, textAlign: "center" }}>
      <SearchBar value={filters.searchQuery} onSearchChange={(val) => updateFilters("searchQuery", val)} />
      <div style={{ display: "flex", maxWidth: 1200, margin: "auto" }}>
        <div style={{ width: 250 }}>
          <Filters filters={filters} onCategoryChange={(val) => updateFilters("category", val)}
            onPriceChange={(val) => updateFilters("minPrice", val.min) || updateFilters("maxPrice", val.max)}
            onRatingChange={(val) => updateFilters("rating", val)} />
          <ClearFiltersButton onClick={clearFilters} />
        </div>
        <div style={{ flex: 1 }}>
          <ProductList products={filteredProducts} />
        </div>
      </div>
    </div>
  );
}

export default App;
